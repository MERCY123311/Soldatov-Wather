//
//  ViewController.swift
//  Fedor Antropov Weather
//
//  Created by Антропов Федор Артемович on 13/2/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

